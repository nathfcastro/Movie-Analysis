# Movie Analysis
Student Name: Nathalie Castro
